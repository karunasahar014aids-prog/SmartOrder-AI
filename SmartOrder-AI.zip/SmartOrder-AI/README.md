# SmartOrder AI — Customer Support Automation

A responsive HTML/CSS/JavaScript prototype for the Skill Development Cell activity **Build Customer Support Automations**.

## Scenario
E-Commerce Customer Support

## Features
- 6 support categories: Order Status, Delivery Delay, Return, Refund, Cancellation, Product Enquiry
- Query classification using keyword-based intent matching
- Automated responses and next-step guidance
- Human support escalation modal
- FAQ section
- Responsive black-and-gold interface
- Privacy reminder to avoid sensitive information

## Run
Open `index.html` in a browser. No server or dependencies are required.

## Demo order
Use `SO-2026-1042` when demonstrating the sample order-status flow.

## Academic note
The AI-assisted component is simulated with transparent keyword intent matching so the prototype can run fully offline. Responses should be reviewed and customized by the student before submission.
